import React  from 'react';
import './App.css';
import PizzaSelection from "./PizzaSelection";
import PizzaPreview from "./PizzaPreview";

export default () => (
    <main>
        <PizzaSelection />
        <PizzaPreview />
    </main>
);
