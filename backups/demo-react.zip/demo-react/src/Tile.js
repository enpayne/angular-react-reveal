import React from 'react';

export default ({ pizza, onSelectPizza }) => (
    <div
        className="pizza-tile"
        onClick={onSelectPizza}
    >
        <div className="pizza-tile__avatar">
            {pizza.name.substring(0, 1)}
        </div>
        <div className="pizza-tile__content">
            <h3 className="pizza-tile__title">{pizza.name}</h3>
            <p className="pizza-tile__description">
                {pizza.ingredients.join(', ')}
            </p>
        </div>
    </div>
)