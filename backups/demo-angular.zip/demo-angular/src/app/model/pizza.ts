export interface Pizza {
  name: String,
  price: Number,
  ingredients: String[]
}
