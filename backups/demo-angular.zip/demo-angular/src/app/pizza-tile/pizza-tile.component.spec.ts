import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzaTileComponent } from './pizza-tile.component';

describe('PizzaTileComponent', () => {
  let component: PizzaTileComponent;
  let fixture: ComponentFixture<PizzaTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PizzaTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzaTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
