import { DemoAngularPage } from './app.po';

describe('demo-angular App', () => {
  let page: DemoAngularPage;

  beforeEach(() => {
    page = new DemoAngularPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
